Members: Shenggui Jin, Sungyeong Jang, Henry Crain
Firebase: https://thelegendofmeta.firebaseapp.com             
(doc is in https://thelegendofmeta.firebaseapp.com/benchmark1)
GitHub: https://github.com/jsgATsbu/CSE-380